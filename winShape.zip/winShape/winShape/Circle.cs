﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace winShape
{
    internal class Circle:Shape
    {
        private int radius;

        public Circle(string name, string color, int noSide, int radius) : base(color, name, noSide)
        {
            this.radius = radius;
        }

        public int Radius
        {
            get => radius; set => radius = value;
        }
        public override double computeArea()
        {
            return Math.PI * (radius * radius);
        }

        public override string ToString()
        {
            return base.ToString() +
                "\nRadius: " + this.Radius +
                "\nArea: " + computeArea().ToString("0.00");
        }

        public void Method()
        {
            Console.WriteLine("This is a method.");
        }
    }
}
