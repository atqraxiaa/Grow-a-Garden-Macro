﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace winShape
{
    internal class Square:Shape
    {
        private int length;

        public Square() { }
        public Square(string name, string color, int noSide, int length) : base(color, name, noSide)
        {
            this.length = length;
        }
        
        public int Length
        {
            get => length; set => length = value; 
        }

        public override double computeArea()
        {
            return length * length;
        }

        public override string ToString()
        {
            return base.ToString() +
                "\nLength: " + this.Length +
                "\nArea: " + computeArea();
        }
    }
}
