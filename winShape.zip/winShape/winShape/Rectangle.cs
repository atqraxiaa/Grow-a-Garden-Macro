﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace winShape
{
    internal class Rectangle:Shape
    {
        private int length;
        private int width;

        public Rectangle() { }
        public Rectangle(string name, string color, int noSide, int length, int width) : base(color, name, noSide)
        {
            this.length = length;
            this.width = width;
        }

        public int Length
        {
            get => length; set => length = value;
        }

        public int Width
        {
            get => width; set => width = value;
        }

        public override double computeArea()
        {
            return length * width;
        }

        public override string ToString()
        {
            return base.ToString() +
                "\nLength: " + this.Length +
                "\nWidth: " + this.Width +
                "\nArea: " + computeArea();
        }
    }
}
