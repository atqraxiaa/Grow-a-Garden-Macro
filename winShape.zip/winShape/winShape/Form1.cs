﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winShape
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // example for square
            Square square = new Square("Red", "Square", 4, 4);
            MessageBox.Show(square.ToString(), "Square Details");

            // example for rectangle
            Rectangle rectangle = new Rectangle("Blue", "Rectangle", 8, 4, 6);
            MessageBox.Show(rectangle.ToString(), "Rectangle Details");

            // example for circle
            Circle circle = new Circle("Yellow", "Circle", 8, 10);
            MessageBox.Show(circle.ToString(), "Circle Details");
        }
    }
}
