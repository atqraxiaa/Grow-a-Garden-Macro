﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace winShape
{
    internal class Shape
    {
        private string color;
        private string name;
        private int noSide;

        public Shape() { }
        public Shape(string name, string color, int noSide)
        {
            this.Color = color;
            this.Name = name;
            this.noSide = noSide;
        }

        public string Color
        {
            get => color; set => color = value;
        }

        public int NoSide
        {
            get => noSide; set => noSide = value;
        }

        public string Name
        {
            get => name; set => name = value;
        }

        public override string ToString()
        {
            return "Name: " + this.Name +
                "\nColor: " + this.Color +
                "\nNo. of sides: " + this.NoSide;
        }

        public virtual double computeArea()
        {
            return 0.0;
        }
    }
}
     