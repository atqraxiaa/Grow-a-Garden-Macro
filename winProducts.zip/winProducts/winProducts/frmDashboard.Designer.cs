﻿namespace testing
{
    partial class frmDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashboard));
            this.picDisplay = new System.Windows.Forms.PictureBox();
            this.btnCart = new System.Windows.Forms.Button();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblQty = new System.Windows.Forms.Label();
            this.lblTotalPrice1 = new System.Windows.Forms.Label();
            this.lblTotalPrice2 = new System.Windows.Forms.Label();
            this.lblProName = new System.Windows.Forms.Label();
            this.lblTotPri2 = new System.Windows.Forms.Label();
            this.lblPriceOut = new System.Windows.Forms.Label();
            this.lblTotPri1 = new System.Windows.Forms.Label();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.lblNamePic = new System.Windows.Forms.Label();
            this.lblPricePic = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picDisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // picDisplay
            // 
            this.picDisplay.Location = new System.Drawing.Point(12, 12);
            this.picDisplay.Name = "picDisplay";
            this.picDisplay.Size = new System.Drawing.Size(187, 159);
            this.picDisplay.TabIndex = 0;
            this.picDisplay.TabStop = false;
            this.picDisplay.Click += new System.EventHandler(this.picDisplay_Click);
            // 
            // btnCart
            // 
            this.btnCart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCart.BackgroundImage")));
            this.btnCart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnCart.Location = new System.Drawing.Point(62, 244);
            this.btnCart.Name = "btnCart";
            this.btnCart.Size = new System.Drawing.Size(83, 47);
            this.btnCart.TabIndex = 1;
            this.btnCart.UseVisualStyleBackColor = true;
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblProductName.Location = new System.Drawing.Point(230, 22);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(98, 17);
            this.lblProductName.TabIndex = 2;
            this.lblProductName.Text = "Product Name";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblPrice.Location = new System.Drawing.Point(230, 61);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(40, 17);
            this.lblPrice.TabIndex = 2;
            this.lblPrice.Text = "Price";
            // 
            // lblQty
            // 
            this.lblQty.AutoSize = true;
            this.lblQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblQty.Location = new System.Drawing.Point(230, 100);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(61, 17);
            this.lblQty.TabIndex = 2;
            this.lblQty.Text = "Quantity";
            // 
            // lblTotalPrice1
            // 
            this.lblTotalPrice1.AutoSize = true;
            this.lblTotalPrice1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblTotalPrice1.Location = new System.Drawing.Point(230, 143);
            this.lblTotalPrice1.Name = "lblTotalPrice1";
            this.lblTotalPrice1.Size = new System.Drawing.Size(76, 17);
            this.lblTotalPrice1.TabIndex = 2;
            this.lblTotalPrice1.Text = "Total Price";
            // 
            // lblTotalPrice2
            // 
            this.lblTotalPrice2.AutoSize = true;
            this.lblTotalPrice2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblTotalPrice2.Location = new System.Drawing.Point(230, 237);
            this.lblTotalPrice2.Name = "lblTotalPrice2";
            this.lblTotalPrice2.Size = new System.Drawing.Size(76, 17);
            this.lblTotalPrice2.TabIndex = 2;
            this.lblTotalPrice2.Text = "Total Price";
            // 
            // lblProName
            // 
            this.lblProName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblProName.Location = new System.Drawing.Point(358, 61);
            this.lblProName.Name = "lblProName";
            this.lblProName.Size = new System.Drawing.Size(125, 17);
            this.lblProName.TabIndex = 2;
            this.lblProName.Text = "<<>>";
            this.lblProName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTotPri2
            // 
            this.lblTotPri2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblTotPri2.Location = new System.Drawing.Point(358, 22);
            this.lblTotPri2.Name = "lblTotPri2";
            this.lblTotPri2.Size = new System.Drawing.Size(125, 17);
            this.lblTotPri2.TabIndex = 2;
            this.lblTotPri2.Text = "<<>>";
            this.lblTotPri2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPriceOut
            // 
            this.lblPriceOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblPriceOut.Location = new System.Drawing.Point(358, 100);
            this.lblPriceOut.Name = "lblPriceOut";
            this.lblPriceOut.Size = new System.Drawing.Size(125, 17);
            this.lblPriceOut.TabIndex = 2;
            this.lblPriceOut.Text = "<<>>";
            this.lblPriceOut.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPriceOut.Click += new System.EventHandler(this.lblPriceOut_Click);
            // 
            // lblTotPri1
            // 
            this.lblTotPri1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblTotPri1.Location = new System.Drawing.Point(358, 237);
            this.lblTotPri1.Name = "lblTotPri1";
            this.lblTotPri1.Size = new System.Drawing.Size(125, 17);
            this.lblTotPri1.TabIndex = 2;
            this.lblTotPri1.Text = "<<>>";
            this.lblTotPri1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(358, 143);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(125, 20);
            this.txtQty.TabIndex = 3;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(525, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(187, 290);
            this.listBox1.TabIndex = 4;
            // 
            // lblNamePic
            // 
            this.lblNamePic.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblNamePic.Location = new System.Drawing.Point(12, 191);
            this.lblNamePic.Name = "lblNamePic";
            this.lblNamePic.Size = new System.Drawing.Size(187, 17);
            this.lblNamePic.TabIndex = 2;
            this.lblNamePic.Text = "Total Price";
            this.lblNamePic.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPricePic
            // 
            this.lblPricePic.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblPricePic.Location = new System.Drawing.Point(12, 208);
            this.lblPricePic.Name = "lblPricePic";
            this.lblPricePic.Size = new System.Drawing.Size(187, 17);
            this.lblPricePic.TabIndex = 2;
            this.lblPricePic.Text = "Total Price";
            this.lblPricePic.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Location = new System.Drawing.Point(12, 185);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 47);
            this.button1.TabIndex = 1;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button2.Location = new System.Drawing.Point(162, 185);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(37, 47);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // frmDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(726, 315);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.lblTotPri2);
            this.Controls.Add(this.lblPricePic);
            this.Controls.Add(this.lblTotalPrice2);
            this.Controls.Add(this.lblTotPri1);
            this.Controls.Add(this.lblNamePic);
            this.Controls.Add(this.lblTotalPrice1);
            this.Controls.Add(this.lblQty);
            this.Controls.Add(this.lblProName);
            this.Controls.Add(this.lblPriceOut);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblProductName);
            this.Controls.Add(this.btnCart);
            this.Controls.Add(this.picDisplay);
            this.Name = "frmDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "testing";
            ((System.ComponentModel.ISupportInitialize)(this.picDisplay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picDisplay;
        private System.Windows.Forms.Button btnCart;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblQty;
        private System.Windows.Forms.Label lblTotalPrice1;
        private System.Windows.Forms.Label lblTotalPrice2;
        private System.Windows.Forms.Label lblProName;
        private System.Windows.Forms.Label lblTotPri2;
        private System.Windows.Forms.Label lblPriceOut;
        private System.Windows.Forms.Label lblTotPri1;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label lblNamePic;
        private System.Windows.Forms.Label lblPricePic;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}