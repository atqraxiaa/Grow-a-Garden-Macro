﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testing
{
    public partial class Dashboard : Form
    {
        private Login Login;
        public Dashboard(Login login)
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void sabonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSabon sabon = new frmSabon();
            sabon.ShowDialog();
        }

        private void shampooToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmShampoo shampoo = new frmShampoo();
            shampoo.ShowDialog();
        }

        private void logodToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmLogod logod = new frmLogod();
            logod.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login.Show();
            this.Close();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            Login.Show();
        }

        private void pToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }
    }
}
