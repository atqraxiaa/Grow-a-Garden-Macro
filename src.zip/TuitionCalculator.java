public class TuitionCalculator {
    protected final int TUITION_PER_UNIT = 450;
    protected final int LAB_FEE = 900;
    protected final int MISCELLANEOUS_FEE = 1500;
    protected final int TUITION_FEE = 500;

    protected int units;
    protected int scholarshipType;
    protected double totalTuition;

    public TuitionCalculator(int units, int scholarshipType) {
        this.units = units;
        this.scholarshipType = scholarshipType;
        calculateTuition();
    }

    public void calculateTuition() {
        double[] scholarshipDiscounts = {1.0, 0.75, 0.50, 0.25, 0.0};
        double discount = scholarshipDiscounts[scholarshipType - 1] * TUITION_FEE;
        totalTuition = (units * TUITION_PER_UNIT) + LAB_FEE + MISCELLANEOUS_FEE - discount;
    }

    public double getTotalTuition() {
        return totalTuition;
    }
}
