import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter student name: ");
        String name = input.nextLine();

        System.out.print("Enter number of units: ");
        int units = input.nextInt();

        System.out.println("Select scholarship type:");
        System.out.println("1. Presidential Scholarship (100% discount)");
        System.out.println("2. College Scholarship (75% discount)");
        System.out.println("3. Department Scholarship (50% discount)");
        System.out.println("4. Non-Academic Scholarship (25% discount)");
        System.out.println("5. Regular Student (0% discount)");
        System.out.print(">> ");
        int scholarshipType = input.nextInt();

        Student student = new Student(name, units, scholarshipType);
        student.displayDetails();
    }
}
