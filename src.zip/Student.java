public class Student extends TuitionCalculator {
    private String studentName;

    public Student(String name, int units, int scholarshipType) {
        super(units, scholarshipType);
        this.studentName = name;
    }

    public void displayDetails() {
        String[] scholarshipNames = {
                "Presidential Scholarship (100% discount)",
                "College Scholarship (75% discount)",
                "Department Scholarship (50% discount)",
                "Non-Academic Scholarship (25% discount)",
                "Regular Student (0% discount)"
        };

        System.out.println("\nName: " + studentName);
        System.out.println("Units: " + units);
        System.out.println("Scholarship Type: " + scholarshipNames[scholarshipType - 1]);
        System.out.println("Total Tuition: $" + totalTuition);
    }
}
